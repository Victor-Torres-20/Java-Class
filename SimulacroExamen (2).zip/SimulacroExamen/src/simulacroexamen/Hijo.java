/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simulacroexamen;

/**
 *
 * @author Jorge Juan
 */
public class Hijo implements Comparable{
    protected String nombre;
    protected String apellido1;
    protected String apellido2;
    protected String dni;
    protected Padre padre;
    protected Padre madre;

    public Hijo(String nombre, String apellido1, String apellido2, String dni) {
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.dni = dni;
    }

    @Override
    public String toString() {
        return "Hijo{" + "nombre=" + nombre + ", apellido1=" + apellido1 + ", apellido2=" + apellido2 + ", dni=" + dni + '}';
    }

    @Override
    public int compareTo(Object t) {
       Hijo otro = (Hijo) t;
       
       return this.nombre.compareTo(otro.nombre);
    }
    
    
}
