/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simulacroexamen;

/**
 *
 * @author Jorge Juan
 */
public class Padre extends Hijo{

    public Padre(String nombre, String apellido1, String apellido2, String dni) {
        super(nombre, apellido1, apellido2, dni);
    }
    
    
    
}
