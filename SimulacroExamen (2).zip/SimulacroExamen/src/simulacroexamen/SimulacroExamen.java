/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simulacroexamen;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Jorge Juan
 */
public class SimulacroExamen {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // FAMILIA1
        // CREAR HIJO, PADRE, ABU Y BIS
        Hijo hij1 = new Hijo("Hijo1","Hijo1","Hijo1","Hijo1");
        Padre pad1 = new Padre("Padre1","Padre1","Padre1","Padre1");
        Abuelo abu1 = new Abuelo("Abuelo1","Abuelo1","Abuelo1","Abuelo1");
        Bisabuelo bis1 = new Bisabuelo("Bisabuelo1","Bisabuelo1","Bisabuelo1","Bisabuelo1");
        List<Hijo> parientes = new ArrayList(3);
        // Elijo el abuelo para hacer la lista de parientes
        parientes.add(hij1);
        parientes.add(pad1);
        parientes.add(bis1);
        Map<Hijo, List<Hijo>> diccionario = new HashMap(); 
        diccionario.put(abu1, parientes);
        java.util.Collections.sort(parientes);
        System.out.println(diccionario.get(abu1));
        

    }

}
